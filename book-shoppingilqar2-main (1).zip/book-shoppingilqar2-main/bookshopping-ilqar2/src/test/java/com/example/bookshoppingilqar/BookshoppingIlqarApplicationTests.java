package com.example.bookshoppingilqar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshoppingIlqarApplicationTests {

	@Test
	void contextLoads() {
	}

}
