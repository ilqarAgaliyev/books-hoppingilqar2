package com.example.bookshoppingilqar.dao;

import com.example.bookshoppingilqar.entity.Customer;


public interface CustomerDao {
	public void saveCustomer(Customer customer);
}
